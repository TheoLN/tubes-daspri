import Utilities as u

def ubahjin(dataJin,jenis):
    Jusn = str(input("Masukkan username jin: "))
    if u.isAvailable(Jusn,dataJin):
        Jenis = None
        index = None
        for i in range(u.my_length(dataJin)):
            if dataJin[i][0] == Jusn:
                Jenis = dataJin[i][2]
                index = i
                break
        if Jenis == "pengumpul":
            print("Jin ini bertipe",f"{jenis}.",end=" ")
            Jenis_baru = input("Yakin ingin mengubah ke tipe “Pembangun” (Y/N)?")
            if Jenis_baru == 'Y':
                dataJin[index][2] == "pembangun"
                print("Jin telah berhasil diubah.")
            else:
                return(dataJin)
        else:
            print("Jin ini bertipe",f"{jenis}.",end=" ")
            Jenis_baru = input("Yakin ingin mengubah ke tipe “Pengumpul” (Y/N)?")
            if Jenis_baru == 'Y':
                dataJin[i][2] == "pengumpul"
                print("Jin telah berhasil diubah.")
            else:
                return(dataJin)
    else:
        print("Tidak ada jin dengan username tersebut.")
        




        